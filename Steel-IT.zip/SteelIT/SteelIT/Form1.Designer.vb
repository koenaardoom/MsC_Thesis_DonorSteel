﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.AddedDatabases = New System.Windows.Forms.TextBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.SelectedFile = New System.Windows.Forms.TextBox()
        Me.BrowseButton = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.YieldStrength = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TestYN = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.YSTextBox = New System.Windows.Forms.TextBox()
        Me.NotifyIcon1 = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.ToS = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Identifier = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.CheckBoxExisting = New System.Windows.Forms.CheckBox()
        Me.CheckBoxTrader = New System.Windows.Forms.CheckBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.SteelPriceTB = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.ScrapPriceTB = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.DistanceTB = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.CoatingCostsTB = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.ModificationNewTB = New System.Windows.Forms.TextBox()
        Me.ModificationRecTB = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.AssemblyCostsTB = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.TensileCostsTB = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.EngineeringCostsTB = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.YearCB = New System.Windows.Forms.ComboBox()
        Me.LabelYear = New System.Windows.Forms.Label()
        Me.ToxicYN = New System.Windows.Forms.ComboBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.InterpreterTB = New System.Windows.Forms.TextBox()
        Me.Button5 = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label1.Location = New System.Drawing.Point(36, 373)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(497, 46)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Donorbuilding database creator"
        '
        'AddedDatabases
        '
        Me.AddedDatabases.Location = New System.Drawing.Point(533, 477)
        Me.AddedDatabases.Multiline = True
        Me.AddedDatabases.Name = "AddedDatabases"
        Me.AddedDatabases.Size = New System.Drawing.Size(269, 283)
        Me.AddedDatabases.TabIndex = 1
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Button2.Location = New System.Drawing.Point(39, 803)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(991, 33)
        Me.Button2.TabIndex = 3
        Me.Button2.Text = "Save settings and continue"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label2.Location = New System.Drawing.Point(36, 419)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(338, 28)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Add new database of donor elements"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(243, 763)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(248, 27)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "Add database -->"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label3.Location = New System.Drawing.Point(38, 454)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(252, 20)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Select excel file with donor elements"
        '
        'SelectedFile
        '
        Me.SelectedFile.Location = New System.Drawing.Point(39, 477)
        Me.SelectedFile.Name = "SelectedFile"
        Me.SelectedFile.Size = New System.Drawing.Size(296, 27)
        Me.SelectedFile.TabIndex = 7
        '
        'BrowseButton
        '
        Me.BrowseButton.Location = New System.Drawing.Point(340, 477)
        Me.BrowseButton.Name = "BrowseButton"
        Me.BrowseButton.Size = New System.Drawing.Size(149, 27)
        Me.BrowseButton.TabIndex = 8
        Me.BrowseButton.Text = "Browse..."
        Me.BrowseButton.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label4.Location = New System.Drawing.Point(39, 560)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(136, 20)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Material properties"
        '
        'YieldStrength
        '
        Me.YieldStrength.Location = New System.Drawing.Point(39, 583)
        Me.YieldStrength.Name = "YieldStrength"
        Me.YieldStrength.Size = New System.Drawing.Size(196, 27)
        Me.YieldStrength.TabIndex = 10
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label5.Location = New System.Drawing.Point(241, 586)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(221, 20)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Yield strength donor steel [MPa]"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label6.Location = New System.Drawing.Point(241, 624)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(243, 20)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "Validated through material testing?"
        '
        'TestYN
        '
        Me.TestYN.FormattingEnabled = True
        Me.TestYN.Location = New System.Drawing.Point(39, 621)
        Me.TestYN.Name = "TestYN"
        Me.TestYN.Size = New System.Drawing.Size(196, 28)
        Me.TestYN.TabIndex = 13
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label7.Location = New System.Drawing.Point(532, 419)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(163, 28)
        Me.Label7.TabIndex = 14
        Me.Label7.Text = "Added databases"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label8.Location = New System.Drawing.Point(532, 454)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(69, 20)
        Me.Label8.TabIndex = 15
        Me.Label8.Text = "Filename"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label9.Location = New System.Drawing.Point(808, 454)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(102, 20)
        Me.Label9.TabIndex = 16
        Me.Label9.Text = "Yield Strength"
        '
        'YSTextBox
        '
        Me.YSTextBox.Location = New System.Drawing.Point(808, 477)
        Me.YSTextBox.Multiline = True
        Me.YSTextBox.Name = "YSTextBox"
        Me.YSTextBox.Size = New System.Drawing.Size(102, 283)
        Me.YSTextBox.TabIndex = 17
        '
        'NotifyIcon1
        '
        Me.NotifyIcon1.Text = "NotifyIcon1"
        Me.NotifyIcon1.Visible = True
        '
        'ToS
        '
        Me.ToS.Location = New System.Drawing.Point(915, 477)
        Me.ToS.Multiline = True
        Me.ToS.Name = "ToS"
        Me.ToS.Size = New System.Drawing.Size(92, 283)
        Me.ToS.TabIndex = 18
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label10.Location = New System.Drawing.Point(915, 454)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(92, 20)
        Me.Label10.TabIndex = 19
        Me.Label10.Text = "Tons of steel"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label11.Location = New System.Drawing.Point(39, 740)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(136, 20)
        Me.Label11.TabIndex = 20
        Me.Label11.Text = "Database identifier"
        '
        'Identifier
        '
        Me.Identifier.Location = New System.Drawing.Point(40, 763)
        Me.Identifier.Name = "Identifier"
        Me.Identifier.Size = New System.Drawing.Size(196, 27)
        Me.Identifier.TabIndex = 21
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label12.Location = New System.Drawing.Point(39, 507)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(239, 20)
        Me.Label12.TabIndex = 22
        Me.Label12.Text = "Source of donor element database"
        '
        'CheckBoxExisting
        '
        Me.CheckBoxExisting.AutoSize = True
        Me.CheckBoxExisting.Location = New System.Drawing.Point(40, 533)
        Me.CheckBoxExisting.Name = "CheckBoxExisting"
        Me.CheckBoxExisting.Size = New System.Drawing.Size(141, 24)
        Me.CheckBoxExisting.TabIndex = 23
        Me.CheckBoxExisting.Text = "Existing building"
        Me.CheckBoxExisting.UseVisualStyleBackColor = True
        '
        'CheckBoxTrader
        '
        Me.CheckBoxTrader.AutoSize = True
        Me.CheckBoxTrader.Location = New System.Drawing.Point(195, 533)
        Me.CheckBoxTrader.Name = "CheckBoxTrader"
        Me.CheckBoxTrader.Size = New System.Drawing.Size(180, 24)
        Me.CheckBoxTrader.TabIndex = 24
        Me.CheckBoxTrader.Text = "Reclaimed steel trader"
        Me.CheckBoxTrader.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(532, 766)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(475, 27)
        Me.Button3.TabIndex = 25
        Me.Button3.Text = "Clear Database..."
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Segoe UI", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label13.Location = New System.Drawing.Point(39, 108)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(441, 46)
        Me.Label13.TabIndex = 26
        Me.Label13.Text = "Cost and impact parameters"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label14.Location = New System.Drawing.Point(36, 154)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(189, 28)
        Me.Label14.TabIndex = 27
        Me.Label14.Text = "Required key figures"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(178, 192)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(201, 20)
        Me.Label15.TabIndex = 28
        Me.Label15.Text = "New steel price [euro per kg]"
        '
        'SteelPriceTB
        '
        Me.SteelPriceTB.Location = New System.Drawing.Point(39, 189)
        Me.SteelPriceTB.Name = "SteelPriceTB"
        Me.SteelPriceTB.Size = New System.Drawing.Size(133, 27)
        Me.SteelPriceTB.TabIndex = 29
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(178, 223)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(208, 20)
        Me.Label16.TabIndex = 30
        Me.Label16.Text = "Steel scrap price [euro per kg]"
        '
        'ScrapPriceTB
        '
        Me.ScrapPriceTB.Location = New System.Drawing.Point(39, 220)
        Me.ScrapPriceTB.Name = "ScrapPriceTB"
        Me.ScrapPriceTB.Size = New System.Drawing.Size(133, 27)
        Me.ScrapPriceTB.TabIndex = 31
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(178, 255)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(286, 20)
        Me.Label17.TabIndex = 32
        Me.Label17.Text = "Distance building site to steelbuilder [km]"
        '
        'DistanceTB
        '
        Me.DistanceTB.Location = New System.Drawing.Point(39, 252)
        Me.DistanceTB.Name = "DistanceTB"
        Me.DistanceTB.Size = New System.Drawing.Size(132, 27)
        Me.DistanceTB.TabIndex = 33
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label18.Location = New System.Drawing.Point(532, 154)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(198, 28)
        Me.Label18.TabIndex = 34
        Me.Label18.Text = "Advanced key figures"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(672, 188)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(388, 20)
        Me.Label19.TabIndex = 35
        Me.Label19.Text = "Cost of sandblasting and painting new steel [euro per kg]"
        '
        'CoatingCostsTB
        '
        Me.CoatingCostsTB.Location = New System.Drawing.Point(532, 185)
        Me.CoatingCostsTB.Name = "CoatingCostsTB"
        Me.CoatingCostsTB.Size = New System.Drawing.Size(134, 27)
        Me.CoatingCostsTB.TabIndex = 36
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(734, 285)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(287, 20)
        Me.Label20.TabIndex = 37
        Me.Label20.Text = "Modification costs new steel [euro per kg]"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(734, 318)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(326, 20)
        Me.Label21.TabIndex = 38
        Me.Label21.Text = "Modification costs reclaimed steel [euro per kg]"
        '
        'ModificationNewTB
        '
        Me.ModificationNewTB.BackColor = System.Drawing.SystemColors.Window
        Me.ModificationNewTB.Location = New System.Drawing.Point(532, 282)
        Me.ModificationNewTB.Name = "ModificationNewTB"
        Me.ModificationNewTB.ReadOnly = True
        Me.ModificationNewTB.Size = New System.Drawing.Size(135, 27)
        Me.ModificationNewTB.TabIndex = 39
        '
        'ModificationRecTB
        '
        Me.ModificationRecTB.BackColor = System.Drawing.SystemColors.Window
        Me.ModificationRecTB.Location = New System.Drawing.Point(532, 314)
        Me.ModificationRecTB.Name = "ModificationRecTB"
        Me.ModificationRecTB.ReadOnly = True
        Me.ModificationRecTB.Size = New System.Drawing.Size(134, 27)
        Me.ModificationRecTB.TabIndex = 40
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(733, 350)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(201, 20)
        Me.Label22.TabIndex = 42
        Me.Label22.Text = "Costs of testing [euro per kg]"
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(672, 282)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(58, 60)
        Me.Button4.TabIndex = 43
        Me.Button4.Text = "Edit.."
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(671, 348)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(58, 26)
        Me.Button6.TabIndex = 45
        Me.Button6.Text = "Edit.."
        Me.Button6.UseVisualStyleBackColor = True
        '
        'AssemblyCostsTB
        '
        Me.AssemblyCostsTB.Location = New System.Drawing.Point(532, 218)
        Me.AssemblyCostsTB.Name = "AssemblyCostsTB"
        Me.AssemblyCostsTB.Size = New System.Drawing.Size(134, 27)
        Me.AssemblyCostsTB.TabIndex = 46
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(672, 223)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(199, 20)
        Me.Label23.TabIndex = 47
        Me.Label23.Text = "Assembly costs [euro per kg]"
        '
        'TensileCostsTB
        '
        Me.TensileCostsTB.BackColor = System.Drawing.SystemColors.Window
        Me.TensileCostsTB.Location = New System.Drawing.Point(531, 347)
        Me.TensileCostsTB.Name = "TensileCostsTB"
        Me.TensileCostsTB.ReadOnly = True
        Me.TensileCostsTB.Size = New System.Drawing.Size(134, 27)
        Me.TensileCostsTB.TabIndex = 41
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(672, 252)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(374, 20)
        Me.Label24.TabIndex = 48
        Me.Label24.Text = "Costs of engineering a new steel structure [euro per kg]"
        '
        'EngineeringCostsTB
        '
        Me.EngineeringCostsTB.Location = New System.Drawing.Point(531, 249)
        Me.EngineeringCostsTB.Name = "EngineeringCostsTB"
        Me.EngineeringCostsTB.Size = New System.Drawing.Size(135, 27)
        Me.EngineeringCostsTB.TabIndex = 49
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label25.Location = New System.Drawing.Point(243, 698)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(186, 20)
        Me.Label25.TabIndex = 50
        Me.Label25.Text = "Toxic conservation systems"
        '
        'YearCB
        '
        Me.YearCB.FormattingEnabled = True
        Me.YearCB.Items.AddRange(New Object() {"1955-1972", "1972-1990", "1990-1997", "1997-2005", "2005-present", "unknown but > 1955"})
        Me.YearCB.Location = New System.Drawing.Point(39, 659)
        Me.YearCB.Name = "YearCB"
        Me.YearCB.Size = New System.Drawing.Size(196, 28)
        Me.YearCB.TabIndex = 54
        Me.YearCB.Visible = False
        '
        'LabelYear
        '
        Me.LabelYear.AutoSize = True
        Me.LabelYear.Location = New System.Drawing.Point(243, 662)
        Me.LabelYear.Name = "LabelYear"
        Me.LabelYear.Size = New System.Drawing.Size(132, 20)
        Me.LabelYear.TabIndex = 55
        Me.LabelYear.Text = "Year of production"
        Me.LabelYear.Visible = False
        '
        'ToxicYN
        '
        Me.ToxicYN.FormattingEnabled = True
        Me.ToxicYN.Items.AddRange(New Object() {"Yes", "No"})
        Me.ToxicYN.Location = New System.Drawing.Point(39, 695)
        Me.ToxicYN.Name = "ToxicYN"
        Me.ToxicYN.Size = New System.Drawing.Size(197, 28)
        Me.ToxicYN.TabIndex = 56
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(805, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(275, 67)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 57
        Me.PictureBox1.TabStop = False
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Segoe UI", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label26.Location = New System.Drawing.Point(36, 12)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(295, 46)
        Me.Label26.TabIndex = 58
        Me.Label26.Text = "Python interpreter"
        '
        'InterpreterTB
        '
        Me.InterpreterTB.Location = New System.Drawing.Point(40, 62)
        Me.InterpreterTB.Name = "InterpreterTB"
        Me.InterpreterTB.Size = New System.Drawing.Size(704, 27)
        Me.InterpreterTB.TabIndex = 59
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(337, 26)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(37, 30)
        Me.Button5.TabIndex = 60
        Me.Button5.Text = "?"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1092, 861)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.InterpreterTB)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.ToxicYN)
        Me.Controls.Add(Me.LabelYear)
        Me.Controls.Add(Me.YearCB)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.EngineeringCostsTB)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.AssemblyCostsTB)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.TensileCostsTB)
        Me.Controls.Add(Me.ModificationRecTB)
        Me.Controls.Add(Me.ModificationNewTB)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.CoatingCostsTB)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.DistanceTB)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.ScrapPriceTB)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.SteelPriceTB)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.CheckBoxTrader)
        Me.Controls.Add(Me.CheckBoxExisting)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Identifier)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.ToS)
        Me.Controls.Add(Me.YSTextBox)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.TestYN)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.YieldStrength)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.AddedDatabases)
        Me.Controls.Add(Me.BrowseButton)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.SelectedFile)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label3)
        Me.Name = "Form1"
        Me.Text = "SteelIT - Database creator"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents AddedDatabases As TextBox
    Friend WithEvents Button2 As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents SelectedFile As TextBox
    Friend WithEvents BrowseButton As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents YieldStrength As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents TestYN As ComboBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents YSTextBox As TextBox
    Friend WithEvents NotifyIcon1 As NotifyIcon
    Friend WithEvents ToS As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Identifier As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents CheckBoxExisting As CheckBox
    Friend WithEvents CheckBoxTrader As CheckBox
    Friend WithEvents Button3 As Button
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents SteelPriceTB As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents ScrapPriceTB As TextBox
    Friend WithEvents Label17 As Label
    Friend WithEvents DistanceTB As TextBox
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents CoatingCostsTB As TextBox
    Friend WithEvents Label20 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents ModificationNewTB As TextBox
    Friend WithEvents ModificationRecTB As TextBox
    Friend WithEvents Label22 As Label
    Friend WithEvents Button4 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents AssemblyCostsTB As TextBox
    Friend WithEvents Label23 As Label
    Friend WithEvents TensileCostsTB As TextBox
    Friend WithEvents Label24 As Label
    Friend WithEvents EngineeringCostsTB As TextBox
    Friend WithEvents Label25 As Label
    Friend WithEvents YearCB As ComboBox
    Friend WithEvents LabelYear As Label
    Friend WithEvents ToxicYN As ComboBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label26 As Label
    Friend WithEvents InterpreterTB As TextBox
    Friend WithEvents Button5 As Button
End Class
