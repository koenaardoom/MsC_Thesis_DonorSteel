﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormModCostsRec
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Cad = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.DrawingNewTB = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ModNewTB = New System.Windows.Forms.TextBox()
        Me.DrawingRecTB = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.ModRecTB = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TransportRecTB = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.CleaningRecTB = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TransportNewTB = New System.Windows.Forms.TextBox()
        Me.CleaningNewTB = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Cad
        '
        Me.Cad.AutoSize = True
        Me.Cad.Location = New System.Drawing.Point(155, 150)
        Me.Cad.Name = "Cad"
        Me.Cad.Size = New System.Drawing.Size(177, 20)
        Me.Cad.TabIndex = 0
        Me.Cad.Text = "Drawing work [eu per kg]"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label1.Location = New System.Drawing.Point(24, 36)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(96, 28)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "New steel"
        '
        'DrawingNewTB
        '
        Me.DrawingNewTB.Location = New System.Drawing.Point(24, 147)
        Me.DrawingNewTB.Name = "DrawingNewTB"
        Me.DrawingNewTB.Size = New System.Drawing.Size(125, 27)
        Me.DrawingNewTB.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(155, 181)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(207, 20)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Modification costs [eu per kg]"
        '
        'ModNewTB
        '
        Me.ModNewTB.Location = New System.Drawing.Point(24, 181)
        Me.ModNewTB.Name = "ModNewTB"
        Me.ModNewTB.Size = New System.Drawing.Size(125, 27)
        Me.ModNewTB.TabIndex = 4
        '
        'DrawingRecTB
        '
        Me.DrawingRecTB.Location = New System.Drawing.Point(393, 147)
        Me.DrawingRecTB.Name = "DrawingRecTB"
        Me.DrawingRecTB.Size = New System.Drawing.Size(125, 27)
        Me.DrawingRecTB.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(524, 150)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(177, 20)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Drawing work [eu per kg]"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(524, 181)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(207, 20)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Modification costs [eu per kg]"
        '
        'ModRecTB
        '
        Me.ModRecTB.Location = New System.Drawing.Point(393, 181)
        Me.ModRecTB.Name = "ModRecTB"
        Me.ModRecTB.Size = New System.Drawing.Size(125, 27)
        Me.ModRecTB.TabIndex = 8
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label5.Location = New System.Drawing.Point(393, 36)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(146, 28)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "Reclaimed steel"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(524, 81)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(147, 20)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "Transport [eu per kg]"
        '
        'TransportRecTB
        '
        Me.TransportRecTB.Location = New System.Drawing.Point(393, 78)
        Me.TransportRecTB.Name = "TransportRecTB"
        Me.TransportRecTB.Size = New System.Drawing.Size(125, 27)
        Me.TransportRecTB.TabIndex = 11
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(524, 115)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(180, 20)
        Me.Label7.TabIndex = 12
        Me.Label7.Text = "Local cleaning [eu per kg]"
        '
        'CleaningRecTB
        '
        Me.CleaningRecTB.Location = New System.Drawing.Point(393, 112)
        Me.CleaningRecTB.Name = "CleaningRecTB"
        Me.CleaningRecTB.Size = New System.Drawing.Size(125, 27)
        Me.CleaningRecTB.TabIndex = 13
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(155, 81)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(147, 20)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "Transport [eu per kg]"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(155, 115)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(180, 20)
        Me.Label9.TabIndex = 15
        Me.Label9.Text = "Local cleaning [eu per kg]"
        '
        'TransportNewTB
        '
        Me.TransportNewTB.Location = New System.Drawing.Point(24, 78)
        Me.TransportNewTB.Name = "TransportNewTB"
        Me.TransportNewTB.Size = New System.Drawing.Size(125, 27)
        Me.TransportNewTB.TabIndex = 16
        '
        'CleaningNewTB
        '
        Me.CleaningNewTB.Location = New System.Drawing.Point(24, 112)
        Me.CleaningNewTB.Name = "CleaningNewTB"
        Me.CleaningNewTB.Size = New System.Drawing.Size(125, 27)
        Me.CleaningNewTB.TabIndex = 17
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(393, 225)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(193, 30)
        Me.Button1.TabIndex = 18
        Me.Button1.Text = "Cancel"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(595, 225)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(193, 30)
        Me.Button2.TabIndex = 19
        Me.Button2.Text = "Save and close"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'FormModCostsRec
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 267)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.CleaningNewTB)
        Me.Controls.Add(Me.TransportNewTB)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.CleaningRecTB)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.TransportRecTB)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.ModRecTB)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.DrawingRecTB)
        Me.Controls.Add(Me.ModNewTB)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.DrawingNewTB)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Cad)
        Me.Name = "FormModCostsRec"
        Me.Text = "Modification costs"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Cad As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents DrawingNewTB As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents ModNewTB As TextBox
    Friend WithEvents DrawingRecTB As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents ModRecTB As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents TransportRecTB As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents CleaningRecTB As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents TransportNewTB As TextBox
    Friend WithEvents CleaningNewTB As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
End Class
