﻿Public Class Form4
    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Hide()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim num1 As Double
        Dim num2 As Double
        Dim num3 As Double
        Dim num4 As Double
        Dim num5 As Double
        Dim num6 As Double
        num1 = Convert.ToDouble(ExtraEngTB.Text) / 100 * 0.15
        num2 = Convert.ToDouble(InventoryTestplanTB.Text)
        num3 = Convert.ToDouble(TensileCostsTB.Text)
        num4 = Convert.ToDouble(ChemcompTB.Text)


        num6 = Math.Round((num1 * 100000 + num2 + num3 * 8 + num4 + num5) / 100000, 2)
        Form1.TensileCostsTB.Text = "0 - " & CStr(num6)
        Me.Hide()
    End Sub
End Class