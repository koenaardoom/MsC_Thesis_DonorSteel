﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form5
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.NewSteelPriceTB = New System.Windows.Forms.TextBox()
        Me.RecSteelPriceTB = New System.Windows.Forms.TextBox()
        Me.MatTestCostsTB = New System.Windows.Forms.TextBox()
        Me.StorageCostsTB = New System.Windows.Forms.TextBox()
        Me.SBPCostsTB = New System.Windows.Forms.TextBox()
        Me.FabCostsTB = New System.Windows.Forms.TextBox()
        Me.AssemblyCostsTB = New System.Windows.Forms.TextBox()
        Me.EngCostsTB = New System.Windows.Forms.TextBox()
        Me.TotalTB = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.RiskTB = New System.Windows.Forms.TextBox()
        Me.SubtotalTB = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.ECIA1A3TB = New System.Windows.Forms.TextBox()
        Me.ECIA4A5TB = New System.Windows.Forms.TextBox()
        Me.ECIBTB = New System.Windows.Forms.TextBox()
        Me.ECICTB = New System.Windows.Forms.TextBox()
        Me.ECIDTB = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.PPA1A3 = New System.Windows.Forms.TextBox()
        Me.PPA4A5 = New System.Windows.Forms.TextBox()
        Me.PPtotal = New System.Windows.Forms.TextBox()
        Me.ECITotalTB = New System.Windows.Forms.TextBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label1.Location = New System.Drawing.Point(21, 33)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(277, 46)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Costs Breakdown"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(153, 96)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(141, 20)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Cost price new steel"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(153, 129)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(180, 20)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Cost price reclaimed steel"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(153, 162)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(170, 20)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Costs of material testing"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(153, 195)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(98, 20)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Storage costs"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(153, 252)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(232, 20)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Cost of sandblasting and painting"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(153, 285)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(119, 20)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Fabrication costs"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(152, 318)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(109, 20)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "Assembly costs"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(152, 351)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(125, 20)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "Engineering costs"
        '
        'NewSteelPriceTB
        '
        Me.NewSteelPriceTB.BackColor = System.Drawing.SystemColors.Window
        Me.NewSteelPriceTB.Location = New System.Drawing.Point(21, 93)
        Me.NewSteelPriceTB.Name = "NewSteelPriceTB"
        Me.NewSteelPriceTB.ReadOnly = True
        Me.NewSteelPriceTB.Size = New System.Drawing.Size(125, 27)
        Me.NewSteelPriceTB.TabIndex = 9
        '
        'RecSteelPriceTB
        '
        Me.RecSteelPriceTB.BackColor = System.Drawing.SystemColors.Window
        Me.RecSteelPriceTB.Location = New System.Drawing.Point(21, 126)
        Me.RecSteelPriceTB.Name = "RecSteelPriceTB"
        Me.RecSteelPriceTB.ReadOnly = True
        Me.RecSteelPriceTB.Size = New System.Drawing.Size(125, 27)
        Me.RecSteelPriceTB.TabIndex = 10
        '
        'MatTestCostsTB
        '
        Me.MatTestCostsTB.BackColor = System.Drawing.SystemColors.Window
        Me.MatTestCostsTB.Location = New System.Drawing.Point(21, 159)
        Me.MatTestCostsTB.Name = "MatTestCostsTB"
        Me.MatTestCostsTB.ReadOnly = True
        Me.MatTestCostsTB.Size = New System.Drawing.Size(125, 27)
        Me.MatTestCostsTB.TabIndex = 11
        '
        'StorageCostsTB
        '
        Me.StorageCostsTB.BackColor = System.Drawing.SystemColors.Window
        Me.StorageCostsTB.Location = New System.Drawing.Point(21, 192)
        Me.StorageCostsTB.Name = "StorageCostsTB"
        Me.StorageCostsTB.ReadOnly = True
        Me.StorageCostsTB.Size = New System.Drawing.Size(125, 27)
        Me.StorageCostsTB.TabIndex = 12
        '
        'SBPCostsTB
        '
        Me.SBPCostsTB.BackColor = System.Drawing.SystemColors.Window
        Me.SBPCostsTB.Location = New System.Drawing.Point(21, 249)
        Me.SBPCostsTB.Name = "SBPCostsTB"
        Me.SBPCostsTB.ReadOnly = True
        Me.SBPCostsTB.Size = New System.Drawing.Size(125, 27)
        Me.SBPCostsTB.TabIndex = 13
        '
        'FabCostsTB
        '
        Me.FabCostsTB.BackColor = System.Drawing.SystemColors.Window
        Me.FabCostsTB.Location = New System.Drawing.Point(21, 282)
        Me.FabCostsTB.Name = "FabCostsTB"
        Me.FabCostsTB.ReadOnly = True
        Me.FabCostsTB.Size = New System.Drawing.Size(125, 27)
        Me.FabCostsTB.TabIndex = 14
        '
        'AssemblyCostsTB
        '
        Me.AssemblyCostsTB.BackColor = System.Drawing.SystemColors.Window
        Me.AssemblyCostsTB.Location = New System.Drawing.Point(21, 315)
        Me.AssemblyCostsTB.Name = "AssemblyCostsTB"
        Me.AssemblyCostsTB.ReadOnly = True
        Me.AssemblyCostsTB.Size = New System.Drawing.Size(125, 27)
        Me.AssemblyCostsTB.TabIndex = 15
        '
        'EngCostsTB
        '
        Me.EngCostsTB.BackColor = System.Drawing.SystemColors.Window
        Me.EngCostsTB.Location = New System.Drawing.Point(21, 348)
        Me.EngCostsTB.Name = "EngCostsTB"
        Me.EngCostsTB.ReadOnly = True
        Me.EngCostsTB.Size = New System.Drawing.Size(125, 27)
        Me.EngCostsTB.TabIndex = 16
        '
        'TotalTB
        '
        Me.TotalTB.BackColor = System.Drawing.SystemColors.Window
        Me.TotalTB.Location = New System.Drawing.Point(21, 480)
        Me.TotalTB.Name = "TotalTB"
        Me.TotalTB.ReadOnly = True
        Me.TotalTB.Size = New System.Drawing.Size(125, 27)
        Me.TotalTB.TabIndex = 17
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(152, 483)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(170, 20)
        Me.Label10.TabIndex = 18
        Me.Label10.Text = "Total costs including risk"
        '
        'RiskTB
        '
        Me.RiskTB.BackColor = System.Drawing.SystemColors.Window
        Me.RiskTB.Location = New System.Drawing.Point(21, 447)
        Me.RiskTB.Name = "RiskTB"
        Me.RiskTB.ReadOnly = True
        Me.RiskTB.Size = New System.Drawing.Size(125, 27)
        Me.RiskTB.TabIndex = 19
        '
        'SubtotalTB
        '
        Me.SubtotalTB.BackColor = System.Drawing.SystemColors.Window
        Me.SubtotalTB.Location = New System.Drawing.Point(21, 414)
        Me.SubtotalTB.Name = "SubtotalTB"
        Me.SubtotalTB.ReadOnly = True
        Me.SubtotalTB.Size = New System.Drawing.Size(125, 27)
        Me.SubtotalTB.TabIndex = 20
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(152, 450)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(35, 20)
        Me.Label11.TabIndex = 21
        Me.Label11.Text = "Risk"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(153, 417)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(122, 20)
        Me.Label12.TabIndex = 22
        Me.Label12.Text = "Total without risk"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(21, 566)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(211, 28)
        Me.Button1.TabIndex = 23
        Me.Button1.Text = "Close"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Segoe UI", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label13.Location = New System.Drawing.Point(455, 33)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(522, 46)
        Me.Label13.TabIndex = 24
        Me.Label13.Text = "Environmental impact breakdown"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(586, 126)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(267, 20)
        Me.Label14.TabIndex = 25
        Me.Label14.Text = "A1 - A3: Production and Manufacturing"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(586, 159)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(149, 20)
        Me.Label15.TabIndex = 26
        Me.Label15.Text = "A4 - A5: Construction"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(586, 192)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(92, 20)
        Me.Label16.TabIndex = 27
        Me.Label16.Text = "B: Use phase"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(586, 225)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(97, 20)
        Me.Label17.TabIndex = 28
        Me.Label17.Text = "C: End-of-life"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(586, 258)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(277, 20)
        Me.Label18.TabIndex = 29
        Me.Label18.Text = "D: Benefits and loads beyond service life"
        '
        'ECIA1A3TB
        '
        Me.ECIA1A3TB.Location = New System.Drawing.Point(455, 123)
        Me.ECIA1A3TB.Name = "ECIA1A3TB"
        Me.ECIA1A3TB.Size = New System.Drawing.Size(125, 27)
        Me.ECIA1A3TB.TabIndex = 30
        '
        'ECIA4A5TB
        '
        Me.ECIA4A5TB.Location = New System.Drawing.Point(455, 156)
        Me.ECIA4A5TB.Name = "ECIA4A5TB"
        Me.ECIA4A5TB.Size = New System.Drawing.Size(125, 27)
        Me.ECIA4A5TB.TabIndex = 31
        '
        'ECIBTB
        '
        Me.ECIBTB.Location = New System.Drawing.Point(455, 189)
        Me.ECIBTB.Name = "ECIBTB"
        Me.ECIBTB.Size = New System.Drawing.Size(125, 27)
        Me.ECIBTB.TabIndex = 32
        '
        'ECICTB
        '
        Me.ECICTB.Location = New System.Drawing.Point(455, 222)
        Me.ECICTB.Name = "ECICTB"
        Me.ECICTB.Size = New System.Drawing.Size(125, 27)
        Me.ECICTB.TabIndex = 33
        '
        'ECIDTB
        '
        Me.ECIDTB.Location = New System.Drawing.Point(455, 255)
        Me.ECIDTB.Name = "ECIDTB"
        Me.ECIDTB.Size = New System.Drawing.Size(125, 27)
        Me.ECIDTB.TabIndex = 34
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label19.Location = New System.Drawing.Point(455, 89)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(319, 28)
        Me.Label19.TabIndex = 35
        Me.Label19.Text = "Environmental cost indicator [euro]"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label20.Location = New System.Drawing.Point(455, 383)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(300, 28)
        Me.Label20.TabIndex = 41
        Me.Label20.Text = "Paris proof indicator [kg CO2-eq]"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(586, 486)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(42, 20)
        Me.Label21.TabIndex = 40
        Me.Label21.Text = "Total"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(586, 453)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(149, 20)
        Me.Label24.TabIndex = 37
        Me.Label24.Text = "A4 - A5: Construction"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(586, 420)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(267, 20)
        Me.Label25.TabIndex = 36
        Me.Label25.Text = "A1 - A3: Production and Manufacturing"
        '
        'PPA1A3
        '
        Me.PPA1A3.Location = New System.Drawing.Point(455, 413)
        Me.PPA1A3.Name = "PPA1A3"
        Me.PPA1A3.Size = New System.Drawing.Size(125, 27)
        Me.PPA1A3.TabIndex = 42
        '
        'PPA4A5
        '
        Me.PPA4A5.Location = New System.Drawing.Point(455, 450)
        Me.PPA4A5.Name = "PPA4A5"
        Me.PPA4A5.Size = New System.Drawing.Size(125, 27)
        Me.PPA4A5.TabIndex = 43
        '
        'PPtotal
        '
        Me.PPtotal.Location = New System.Drawing.Point(455, 483)
        Me.PPtotal.Name = "PPtotal"
        Me.PPtotal.Size = New System.Drawing.Size(125, 27)
        Me.PPtotal.TabIndex = 45
        '
        'ECITotalTB
        '
        Me.ECITotalTB.Location = New System.Drawing.Point(455, 288)
        Me.ECITotalTB.Name = "ECITotalTB"
        Me.ECITotalTB.Size = New System.Drawing.Size(125, 27)
        Me.ECITotalTB.TabIndex = 47
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(586, 291)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(42, 20)
        Me.Label26.TabIndex = 48
        Me.Label26.Text = "Total"
        '
        'Form5
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1000, 626)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.ECITotalTB)
        Me.Controls.Add(Me.PPtotal)
        Me.Controls.Add(Me.PPA4A5)
        Me.Controls.Add(Me.PPA1A3)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.ECIDTB)
        Me.Controls.Add(Me.ECICTB)
        Me.Controls.Add(Me.ECIBTB)
        Me.Controls.Add(Me.ECIA4A5TB)
        Me.Controls.Add(Me.ECIA1A3TB)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.SubtotalTB)
        Me.Controls.Add(Me.RiskTB)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.TotalTB)
        Me.Controls.Add(Me.EngCostsTB)
        Me.Controls.Add(Me.AssemblyCostsTB)
        Me.Controls.Add(Me.FabCostsTB)
        Me.Controls.Add(Me.SBPCostsTB)
        Me.Controls.Add(Me.StorageCostsTB)
        Me.Controls.Add(Me.MatTestCostsTB)
        Me.Controls.Add(Me.RecSteelPriceTB)
        Me.Controls.Add(Me.NewSteelPriceTB)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form5"
        Me.Text = "Cost and environmental impact details"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents NewSteelPriceTB As TextBox
    Friend WithEvents RecSteelPriceTB As TextBox
    Friend WithEvents MatTestCostsTB As TextBox
    Friend WithEvents StorageCostsTB As TextBox
    Friend WithEvents SBPCostsTB As TextBox
    Friend WithEvents FabCostsTB As TextBox
    Friend WithEvents AssemblyCostsTB As TextBox
    Friend WithEvents EngCostsTB As TextBox
    Friend WithEvents TotalTB As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents RiskTB As TextBox
    Friend WithEvents SubtotalTB As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents ECIA1A3TB As TextBox
    Friend WithEvents ECIA4A5TB As TextBox
    Friend WithEvents ECIBTB As TextBox
    Friend WithEvents ECICTB As TextBox
    Friend WithEvents ECIDTB As TextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents PPA1A3 As TextBox
    Friend WithEvents PPA4A5 As TextBox
    Friend WithEvents PPtotal As TextBox
    Friend WithEvents ECITotalTB As TextBox
    Friend WithEvents Label26 As Label
End Class
