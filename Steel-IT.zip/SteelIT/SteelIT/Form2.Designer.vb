﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form2))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SteelITButton = New System.Windows.Forms.Button()
        Me.GenStock = New System.Windows.Forms.Button()
        Me.DonorStock = New System.Windows.Forms.PictureBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.DesignNameTB = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.WmultTB = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.UsefulTB = New System.Windows.Forms.TextBox()
        Me.ProgressTB = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.NewSteelSumTB = New System.Windows.Forms.TextBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.RecSum1TB = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.RecSum2TB = New System.Windows.Forms.TextBox()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.SolutionCloudGraph = New System.Windows.Forms.PictureBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.SliderConReuse = New System.Windows.Forms.TrackBar()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.PercentageReuse = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.ModelSelect = New System.Windows.Forms.ComboBox()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.NewSteelSum2TB = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.SliderConReuse2 = New System.Windows.Forms.TrackBar()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.ChoiceCloudGraph = New System.Windows.Forms.ComboBox()
        Me.PercentageReuse2 = New System.Windows.Forms.Label()
        CType(Me.DonorStock, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SolutionCloudGraph, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SliderConReuse, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SliderConReuse2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label1.Location = New System.Drawing.Point(26, 7)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(281, 37)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Database visualisation"
        '
        'SteelITButton
        '
        Me.SteelITButton.Location = New System.Drawing.Point(829, 311)
        Me.SteelITButton.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.SteelITButton.Name = "SteelITButton"
        Me.SteelITButton.Size = New System.Drawing.Size(179, 22)
        Me.SteelITButton.TabIndex = 4
        Me.SteelITButton.Text = "Steel IT..."
        Me.SteelITButton.UseVisualStyleBackColor = True
        '
        'GenStock
        '
        Me.GenStock.Location = New System.Drawing.Point(414, 13)
        Me.GenStock.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GenStock.Name = "GenStock"
        Me.GenStock.Size = New System.Drawing.Size(239, 26)
        Me.GenStock.TabIndex = 10
        Me.GenStock.Text = "Show available elements in database"
        Me.GenStock.UseVisualStyleBackColor = True
        '
        'DonorStock
        '
        Me.DonorStock.Location = New System.Drawing.Point(26, 44)
        Me.DonorStock.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.DonorStock.Name = "DonorStock"
        Me.DonorStock.Size = New System.Drawing.Size(626, 255)
        Me.DonorStock.TabIndex = 11
        Me.DonorStock.TabStop = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label5.Location = New System.Drawing.Point(675, 9)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(498, 37)
        Me.Label5.TabIndex = 13
        Me.Label5.Text = "Create design and reclaimed alternatives"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label6.Location = New System.Drawing.Point(675, 131)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(138, 21)
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "Algorithm settings"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(675, 97)
        Me.Button1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(333, 24)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Launch design environment..."
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(924, 74)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(76, 15)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Design name"
        '
        'DesignNameTB
        '
        Me.DesignNameTB.Location = New System.Drawing.Point(675, 72)
        Me.DesignNameTB.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.DesignNameTB.Name = "DesignNameTB"
        Me.DesignNameTB.Size = New System.Drawing.Size(245, 23)
        Me.DesignNameTB.TabIndex = 3
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label4.Location = New System.Drawing.Point(675, 44)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(153, 21)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "Name and geometry"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label3.Location = New System.Drawing.Point(675, 311)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(136, 21)
        Me.Label3.TabIndex = 20
        Me.Label3.Text = "Run the algorithm"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Segoe UI", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label9.Location = New System.Drawing.Point(26, 317)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(189, 37)
        Me.Label9.TabIndex = 22
        Me.Label9.Text = "Solution cloud"
        '
        'WmultTB
        '
        Me.WmultTB.Location = New System.Drawing.Point(675, 154)
        Me.WmultTB.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.WmultTB.Name = "WmultTB"
        Me.WmultTB.Size = New System.Drawing.Size(58, 23)
        Me.WmultTB.TabIndex = 23
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(738, 157)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(217, 15)
        Me.Label10.TabIndex = 24
        Me.Label10.Text = "Maximum weight multiplier donor steel"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(738, 179)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(227, 15)
        Me.Label11.TabIndex = 25
        Me.Label11.Text = "Minimum useful length cut-off waste [m]"
        '
        'UsefulTB
        '
        Me.UsefulTB.Location = New System.Drawing.Point(675, 177)
        Me.UsefulTB.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.UsefulTB.Name = "UsefulTB"
        Me.UsefulTB.Size = New System.Drawing.Size(58, 23)
        Me.UsefulTB.TabIndex = 26
        '
        'ProgressTB
        '
        Me.ProgressTB.Location = New System.Drawing.Point(675, 338)
        Me.ProgressTB.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ProgressTB.Multiline = True
        Me.ProgressTB.Name = "ProgressTB"
        Me.ProgressTB.ReadOnly = True
        Me.ProgressTB.Size = New System.Drawing.Size(334, 44)
        Me.ProgressTB.TabIndex = 27
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label12.Location = New System.Drawing.Point(1045, 44)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(180, 21)
        Me.Label12.TabIndex = 28
        Me.Label12.Text = "Results of the algorithm "
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(1045, 229)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(105, 15)
        Me.Label13.TabIndex = 29
        Me.Label13.Text = "Portal frame - new"
        '
        'NewSteelSumTB
        '
        Me.NewSteelSumTB.Location = New System.Drawing.Point(1045, 90)
        Me.NewSteelSumTB.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.NewSteelSumTB.Multiline = True
        Me.NewSteelSumTB.Name = "NewSteelSumTB"
        Me.NewSteelSumTB.Size = New System.Drawing.Size(355, 54)
        Me.NewSteelSumTB.TabIndex = 30
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(1253, 226)
        Me.Button2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(146, 18)
        Me.Button2.TabIndex = 31
        Me.Button2.Text = "Details..."
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(675, 388)
        Me.Button6.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(333, 22)
        Me.Button6.TabIndex = 32
        Me.Button6.Text = "Accept design"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(1045, 151)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(143, 15)
        Me.Label14.TabIndex = 33
        Me.Label14.Text = "Braced frame - reclaimed "
        '
        'RecSum1TB
        '
        Me.RecSum1TB.Location = New System.Drawing.Point(1045, 168)
        Me.RecSum1TB.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.RecSum1TB.Multiline = True
        Me.RecSum1TB.Name = "RecSum1TB"
        Me.RecSum1TB.Size = New System.Drawing.Size(355, 54)
        Me.RecSum1TB.TabIndex = 34
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(1047, 311)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(135, 15)
        Me.Label15.TabIndex = 35
        Me.Label15.Text = "Portal frame - reclaimed"
        '
        'RecSum2TB
        '
        Me.RecSum2TB.Location = New System.Drawing.Point(1047, 328)
        Me.RecSum2TB.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.RecSum2TB.Multiline = True
        Me.RecSum2TB.Name = "RecSum2TB"
        Me.RecSum2TB.Size = New System.Drawing.Size(355, 54)
        Me.RecSum2TB.TabIndex = 36
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(1253, 148)
        Me.Button7.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(146, 18)
        Me.Button7.TabIndex = 37
        Me.Button7.Text = "Details..."
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(1256, 308)
        Me.Button8.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(146, 18)
        Me.Button8.TabIndex = 39
        Me.Button8.Text = "Details..."
        Me.Button8.UseVisualStyleBackColor = True
        '
        'SolutionCloudGraph
        '
        Me.SolutionCloudGraph.Location = New System.Drawing.Point(26, 354)
        Me.SolutionCloudGraph.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.SolutionCloudGraph.Name = "SolutionCloudGraph"
        Me.SolutionCloudGraph.Size = New System.Drawing.Size(626, 384)
        Me.SolutionCloudGraph.TabIndex = 43
        Me.SolutionCloudGraph.TabStop = False
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(1045, 388)
        Me.Button4.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(354, 22)
        Me.Button4.TabIndex = 44
        Me.Button4.Text = "Update solution cloud"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(505, 327)
        Me.Button5.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(148, 22)
        Me.Button5.TabIndex = 45
        Me.Button5.Text = "Refresh"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'SliderConReuse
        '
        Me.SliderConReuse.LargeChange = 10
        Me.SliderConReuse.Location = New System.Drawing.Point(675, 225)
        Me.SliderConReuse.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.SliderConReuse.Maximum = 100
        Me.SliderConReuse.Name = "SliderConReuse"
        Me.SliderConReuse.Size = New System.Drawing.Size(333, 45)
        Me.SliderConReuse.SmallChange = 5
        Me.SliderConReuse.TabIndex = 20
        Me.SliderConReuse.TickFrequency = 5
        Me.SliderConReuse.TickStyle = System.Windows.Forms.TickStyle.None
        Me.SliderConReuse.Value = 50
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(675, 206)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(228, 15)
        Me.Label7.TabIndex = 47
        Me.Label7.Text = "Reuse percentage of connections model 1"
        '
        'PercentageReuse
        '
        Me.PercentageReuse.AutoSize = True
        Me.PercentageReuse.Location = New System.Drawing.Point(947, 206)
        Me.PercentageReuse.Name = "PercentageReuse"
        Me.PercentageReuse.Size = New System.Drawing.Size(50, 15)
        Me.PercentageReuse.TabIndex = 48
        Me.PercentageReuse.Text = "Label 17"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label8.Location = New System.Drawing.Point(680, 458)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(304, 21)
        Me.Label8.TabIndex = 49
        Me.Label8.Text = "Used donor elements in reclaimed designs"
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(682, 496)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(719, 242)
        Me.PictureBox1.TabIndex = 50
        Me.PictureBox1.TabStop = False
        '
        'ModelSelect
        '
        Me.ModelSelect.FormattingEnabled = True
        Me.ModelSelect.Items.AddRange(New Object() {"Model 1", "Model 2"})
        Me.ModelSelect.Location = New System.Drawing.Point(1045, 458)
        Me.ModelSelect.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ModelSelect.Name = "ModelSelect"
        Me.ModelSelect.Size = New System.Drawing.Size(162, 23)
        Me.ModelSelect.TabIndex = 51
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(1226, 457)
        Me.Button9.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(173, 21)
        Me.Button9.TabIndex = 52
        Me.Button9.Text = "Refresh"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(26, 742)
        Me.Button3.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(154, 23)
        Me.Button3.TabIndex = 5
        Me.Button3.Text = "Back"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'NewSteelSum2TB
        '
        Me.NewSteelSum2TB.Location = New System.Drawing.Point(1045, 246)
        Me.NewSteelSum2TB.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.NewSteelSum2TB.Multiline = True
        Me.NewSteelSum2TB.Name = "NewSteelSum2TB"
        Me.NewSteelSum2TB.Size = New System.Drawing.Size(355, 54)
        Me.NewSteelSum2TB.TabIndex = 53
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(1045, 74)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(110, 15)
        Me.Label16.TabIndex = 54
        Me.Label16.Text = "Braced frame - new"
        '
        'SliderConReuse2
        '
        Me.SliderConReuse2.LargeChange = 10
        Me.SliderConReuse2.Location = New System.Drawing.Point(675, 272)
        Me.SliderConReuse2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.SliderConReuse2.Maximum = 100
        Me.SliderConReuse2.Name = "SliderConReuse2"
        Me.SliderConReuse2.Size = New System.Drawing.Size(333, 45)
        Me.SliderConReuse2.SmallChange = 5
        Me.SliderConReuse2.TabIndex = 20
        Me.SliderConReuse2.TickFrequency = 5
        Me.SliderConReuse2.TickStyle = System.Windows.Forms.TickStyle.None
        Me.SliderConReuse2.Value = 50
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(675, 252)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(214, 15)
        Me.Label17.TabIndex = 55
        Me.Label17.Text = "Reuse percentage connections model 2"
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(1253, 68)
        Me.Button10.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(146, 18)
        Me.Button10.TabIndex = 56
        Me.Button10.Text = "Details..."
        Me.Button10.UseVisualStyleBackColor = True
        '
        'ChoiceCloudGraph
        '
        Me.ChoiceCloudGraph.FormattingEnabled = True
        Me.ChoiceCloudGraph.Items.AddRange(New Object() {"Environmental Cost Indicator (ECI)", "Paris Proof Indicator (PPI)"})
        Me.ChoiceCloudGraph.Location = New System.Drawing.Point(234, 328)
        Me.ChoiceCloudGraph.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ChoiceCloudGraph.Name = "ChoiceCloudGraph"
        Me.ChoiceCloudGraph.Size = New System.Drawing.Size(266, 23)
        Me.ChoiceCloudGraph.TabIndex = 57
        '
        'PercentageReuse2
        '
        Me.PercentageReuse2.AutoSize = True
        Me.PercentageReuse2.Location = New System.Drawing.Point(947, 252)
        Me.PercentageReuse2.Name = "PercentageReuse2"
        Me.PercentageReuse2.Size = New System.Drawing.Size(47, 15)
        Me.PercentageReuse2.TabIndex = 58
        Me.PercentageReuse2.Text = "Label18"
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLight
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(1427, 775)
        Me.Controls.Add(Me.PercentageReuse2)
        Me.Controls.Add(Me.ChoiceCloudGraph)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.SliderConReuse2)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.NewSteelSum2TB)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.ModelSelect)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.PercentageReuse)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.SliderConReuse)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.SolutionCloudGraph)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.RecSum2TB)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.RecSum1TB)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.NewSteelSumTB)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.ProgressTB)
        Me.Controls.Add(Me.UsefulTB)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.WmultTB)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.DonorStock)
        Me.Controls.Add(Me.GenStock)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.SteelITButton)
        Me.Controls.Add(Me.DesignNameTB)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button1)
        Me.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "Form2"
        Me.Text = "Z "
        Me.TopMost = True
        CType(Me.DonorStock, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SolutionCloudGraph, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SliderConReuse, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SliderConReuse2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As Label
    Friend WithEvents SteelITButton As Button
    Friend WithEvents GenStock As Button
    Friend WithEvents DonorStock As PictureBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents DesignNameTB As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents WmultTB As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents UsefulTB As TextBox
    Friend WithEvents ProgressTB As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents NewSteelSumTB As TextBox
    Friend WithEvents Button2 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Label14 As Label
    Friend WithEvents RecSum1TB As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents RecSum2TB As TextBox
    Friend WithEvents Button7 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents SolutionCloudGraph As PictureBox
    Friend WithEvents Button4 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents SliderConReuse As TrackBar
    Friend WithEvents Label7 As Label
    Friend WithEvents PercentageReuse As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents ModelSelect As ComboBox
    Friend WithEvents Button9 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents NewSteelSum2TB As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents SliderConReuse2 As TrackBar
    Friend WithEvents Label17 As Label
    Friend WithEvents Button10 As Button
    Friend WithEvents ChoiceCloudGraph As ComboBox
    Friend WithEvents PercentageReuse2 As Label
End Class
