﻿Public Class FormModCostsRec
    Private Sub FormModCostsRec_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CleaningNewTB.Text = "0.00"
        CleaningRecTB.Text = "0.10"
        DrawingNewTB.Text = "0.05"
        DrawingRecTB.Text = "0.10"
        ModNewTB.Text = "0.70"
        ModRecTB.Text = "0.90"
        TransportNewTB.Text = "0.00"
        TransportRecTB.Text = "0.05"
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Hide()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim num1 As Double
        Dim num2 As Double
        Dim num3 As Double
        Dim num4 As Double
        Dim num5 As Double
        num1 = Convert.ToDouble(CleaningNewTB.Text)
        num2 = Convert.ToDouble(DrawingNewTB.Text)
        num3 = Convert.ToDouble(ModNewTB.Text)
        num4 = Convert.ToDouble(TransportNewTB.Text)
        num5 = num1 + num2 + num3 + num4
        Form1.ModificationNewTB.Text = CStr(num5)

        Dim num6 As Double
        Dim num7 As Double
        Dim num8 As Double
        Dim num9 As Double
        Dim num10 As Double
        num6 = Convert.ToDouble(CleaningRecTB.Text)
        num7 = Convert.ToDouble(DrawingRecTB.Text)
        num8 = Convert.ToDouble(ModRecTB.Text)
        num9 = Convert.ToDouble(TransportRecTB.Text)
        num10 = num6 + num7 + num8 + num9
        Form1.ModificationRecTB.Text = CStr(num10)

        Me.Hide()
    End Sub

End Class