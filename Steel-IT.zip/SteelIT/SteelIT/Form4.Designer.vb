﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form4
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ExtraEngTB = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.InventoryTestplanTB = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TensileCostsTB = New System.Windows.Forms.TextBox()
        Me.ChemcompTB = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'ExtraEngTB
        '
        Me.ExtraEngTB.Location = New System.Drawing.Point(24, 41)
        Me.ExtraEngTB.Name = "ExtraEngTB"
        Me.ExtraEngTB.Size = New System.Drawing.Size(125, 27)
        Me.ExtraEngTB.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(155, 44)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(433, 20)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Percentage extra engineering recalculating existing structure [%]"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(155, 110)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(224, 20)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Costs per tenstile test [euro/test]"
        '
        'InventoryTestplanTB
        '
        Me.InventoryTestplanTB.Location = New System.Drawing.Point(24, 74)
        Me.InventoryTestplanTB.Name = "InventoryTestplanTB"
        Me.InventoryTestplanTB.Size = New System.Drawing.Size(125, 27)
        Me.InventoryTestplanTB.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(155, 77)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(378, 20)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Inventarisation/testplan day-costs [euro/20 test-groups]"
        '
        'TensileCostsTB
        '
        Me.TensileCostsTB.Location = New System.Drawing.Point(24, 107)
        Me.TensileCostsTB.Name = "TensileCostsTB"
        Me.TensileCostsTB.Size = New System.Drawing.Size(125, 27)
        Me.TensileCostsTB.TabIndex = 5
        '
        'ChemcompTB
        '
        Me.ChemcompTB.Location = New System.Drawing.Point(24, 140)
        Me.ChemcompTB.Name = "ChemcompTB"
        Me.ChemcompTB.Size = New System.Drawing.Size(125, 27)
        Me.ChemcompTB.TabIndex = 6
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(155, 143)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(483, 20)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Extra day-costs for chemical composition analysis [euro/20 test-groups]"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(12, 173)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(220, 29)
        Me.Button1.TabIndex = 10
        Me.Button1.Text = "Cancel"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(272, 173)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(220, 29)
        Me.Button2.TabIndex = 11
        Me.Button2.Text = "Save and close"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label6.Location = New System.Drawing.Point(12, 5)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(160, 28)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "Key-figures costs"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(606, 44)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(0, 20)
        Me.Label8.TabIndex = 14
        '
        'Form4
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(724, 215)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.ChemcompTB)
        Me.Controls.Add(Me.TensileCostsTB)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.InventoryTestplanTB)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.ExtraEngTB)
        Me.Name = "Form4"
        Me.Text = "Material testing costs"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ExtraEngTB As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents InventoryTestplanTB As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents TensileCostsTB As TextBox
    Friend WithEvents ChemcompTB As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents Label8 As Label
End Class
