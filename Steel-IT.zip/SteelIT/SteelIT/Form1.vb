﻿Public Class Form1
    Public FileNametxt As String
    Public FileNametxt2 As String
    Public Trader As String
    Public Value As String
    Public InterpreterPath As String
    Private Function GetFileName_OtherMethod(ByVal path As String) As String
        Dim _filename As String = ""
        Dim sep() As Char = {"/", "\", "//"}
        _filename = path.Split(sep).Last()
        Return _filename
    End Function

    Private Sub AddLine(ByVal line As String)
        Me.AddedDatabases.Text = If(Me.AddedDatabases.Text = String.Empty, line, Me.AddedDatabases.Text & ControlChars.CrLf & line)
    End Sub

    Private Sub AddLine2(ByVal line As String)
        Me.YSTextBox.Text = If(Me.YSTextBox.Text = String.Empty, line, Me.YSTextBox.Text & ControlChars.CrLf & line)
    End Sub

    Public Sub proccess_OutputDataReceived(ByVal sender As Object, ByVal e As DataReceivedEventArgs)
        On Error Resume Next
        If e.Data = "" Then
        Else
            Value = e.Data

        End If
    End Sub

    Private Sub AddLine3(ByVal line As String)
        Me.ToS.Text = If(Me.ToS.Text = String.Empty, line, Me.ToS.Text & ControlChars.CrLf & line)
    End Sub

    Private Sub BrowseButton_Click(sender As Object, e As EventArgs) Handles BrowseButton.Click
        Dim fd As OpenFileDialog = New OpenFileDialog()

        fd.Title = "Open file dialog"
        fd.InitialDirectory = "C:\\"
        fd.Filter = "All files (*.*)|*.*|All files (*.*)|*.*"
        fd.FilterIndex = 1
        fd.RestoreDirectory = True

        If fd.ShowDialog() = DialogResult.OK Then
            SelectedFile.Text = fd.FileName
        End If
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TestYN.Items.Clear()
        TestYN.Items.Add("Yes")
        TestYN.Items.Add("No")
        FileNametxt = My.Computer.FileSystem.CurrentDirectory + "\Databases.txt"
        System.IO.File.WriteAllText(FileNametxt, "")
        FileNametxt2 = My.Computer.FileSystem.CurrentDirectory + "\costparams.txt"
        System.IO.File.WriteAllText(FileNametxt2, "")
        My.Computer.FileSystem.CopyFile(My.Computer.FileSystem.CurrentDirectory + "\Database_Template.xlsx", My.Computer.FileSystem.CurrentDirectory + "\Database.xlsx", True)
        CoatingCostsTB.Text = "0.25"
        ModificationNewTB.Text = "0.75"
        TensileCostsTB.Text = "0 - 0.06"
        ModificationRecTB.Text = "1.20"
        AssemblyCostsTB.Text = "0.90"
        EngineeringCostsTB.Text = "0.15"
        FormModCostsRec.CleaningRecTB.Text = "0.10"
        Form4.ChemcompTB.Text = "700"
        Form4.TensileCostsTB.Text = "150"
        Form4.InventoryTestplanTB.Text = "2500"
        Form4.ExtraEngTB.Text = "10"

        YearCB.Visible = False
        LabelYear.Visible = False

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim num10 As Double
        If ToxicYN.Text = "Yes" Then
            num10 = Convert.ToDouble(Form4.InventoryTestplanTB.Text) + Convert.ToDouble(Form4.ChemcompTB.Text)
        End If

        If ToxicYN.Text = "No" Then
            num10 = Convert.ToDouble(Form4.InventoryTestplanTB.Text)
        End If

        Dim p As New Process
        p.StartInfo.Arguments = "AppendDatabase.py " & """" + SelectedFile.Text + """" & " " & YieldStrength.Text & " " & TestYN.Text & " " & Trader & " " & Identifier.Text & " " & ToxicYN.Text & " " & Convert.ToString(num10) & " " & Form4.TensileCostsTB.Text & " " & EngineeringCostsTB.Text & " " & Form4.ExtraEngTB.Text & " " & FormModCostsRec.CleaningRecTB.Text & " " & YearCB.Text & " " & ScrapPriceTB.Text
        p.StartInfo.FileName = InterpreterTB.Text
        p.StartInfo.UseShellExecute = False
        p.StartInfo.RedirectStandardOutput = True
        p.StartInfo.RedirectStandardOutput = True
        p.StartInfo.CreateNoWindow = True
        p.StartInfo.WindowStyle = ProcessWindowStyle.Hidden
        p.EnableRaisingEvents = True

        p.Start()

        AddHandler p.OutputDataReceived, AddressOf proccess_OutputDataReceived
        p.BeginOutputReadLine()
        p.WaitForExit()


        AddLine(GetFileName_OtherMethod(SelectedFile.Text))
        AddLine2(YieldStrength.Text)
        AddLine3(Value)
        My.Computer.FileSystem.WriteAllText(FileNametxt, Identifier.Text + ", " + YieldStrength.Text + ", " + TestYN.Text + ", " + Convert.ToString(num10) + Environment.NewLine, True)

        Dim q As New Process
        q.StartInfo.Arguments = "InitialView.py " & "Database.xlsx"
        q.StartInfo.FileName = InterpreterTB.Text
        q.StartInfo.UseShellExecute = False
        q.StartInfo.RedirectStandardOutput = True
        q.StartInfo.RedirectStandardOutput = True
        q.StartInfo.CreateNoWindow = True
        q.StartInfo.WindowStyle = ProcessWindowStyle.Hidden
        q.EnableRaisingEvents = True
        q.Start()

    End Sub

    Private Sub CheckBoxExisting_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxExisting.CheckedChanged
        CheckBoxTrader.Checked = False
        Trader = "No"

    End Sub

    Private Sub CheckBoxTrader_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxTrader.CheckedChanged
        CheckBoxExisting.Checked = False
        Trader = "Yes"
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        My.Computer.FileSystem.CopyFile(My.Computer.FileSystem.CurrentDirectory + "\Database_Template.xlsx", My.Computer.FileSystem.CurrentDirectory + "\Database.xlsx", True)
        AddedDatabases.Clear()
        YSTextBox.Clear()
        ToS.Clear()
        SelectedFile.Clear()
        YieldStrength.Clear()
        Identifier.Clear()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        My.Computer.FileSystem.WriteAllText(FileNametxt2, SteelPriceTB.Text + ", " + ScrapPriceTB.Text + ", " + CoatingCostsTB.Text + ", " + ModificationNewTB.Text + ", " + ModificationRecTB.Text + ", " + AssemblyCostsTB.Text + ", " + EngineeringCostsTB.Text + ", " + DistanceTB.Text + ", " + Form4.ExtraEngTB.Text + ", " + Form4.InventoryTestplanTB.Text + ", " + Form4.TensileCostsTB.Text + ", " + Form4.ChemcompTB.Text, True)
        InterpreterPath = InterpreterTB.Text
        Me.Hide()
        Form2.Show()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        FormModCostsRec.Show()
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Form4.Show()
    End Sub

    Private Sub TestYN_SelectedIndexChanged(sender As Object, e As EventArgs) Handles TestYN.SelectedIndexChanged
        If TestYN.Text = "Yes" Then
            YearCB.Visible = False
            LabelYear.Visible = False
        End If
        If TestYN.Text = "No" Then
            LabelYear.Visible = True
            YearCB.Visible = True
        End If
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Form6.Show()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Form7.Show()
    End Sub
End Class
