﻿
Imports System.Diagnostics
Public Class Form2
    Public Value As String
    Public Valuee As String
    Public FileNametxt3 As String

    Public Sub proccess_OutputDataReceived(ByVal sender As Object, ByVal e As DataReceivedEventArgs)
        On Error Resume Next
        If e.Data = "" Then
        Else
            Value = e.Data

        End If
    End Sub

    Public Sub proccess_OutputDataReceived2(ByVal sender As Object, ByVal e As DataReceivedEventArgs)
        On Error Resume Next
        If e.Data = "" Then
        Else
            Valuee = e.Data

        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim pr As New Process
        pr.StartInfo.FileName = My.Computer.FileSystem.CurrentDirectory + "\DesignCreator.gh"
        pr.StartInfo.UseShellExecute = True
        pr.Start()

    End Sub

    Private Sub GenStock_Click(sender As Object, e As EventArgs) Handles GenStock.Click
        Dim b1 As Image = Image.FromFile(My.Computer.FileSystem.CurrentDirectory + "\Initialviewofelements.png")
        Dim b2 As New Bitmap(DonorStock.Width, DonorStock.Height)
        Using g As Graphics = Graphics.FromImage(b2)
            g.DrawImage(b1, 0, 0, DonorStock.Width, DonorStock.Height)
        End Using

        Dim myImage As Image = b2

        DonorStock.Image = myImage
        b1.Dispose()
    End Sub

    Private Sub SteelITButton_Click(sender As Object, e As EventArgs) Handles SteelITButton.Click
        ProgressTB.Text = "Running the algorithm. Please wait..."

        Dim r As New Process
        r.StartInfo.Arguments = "TheCodeV2.py " & WmultTB.Text & " " & UsefulTB.Text & " " & DesignNameTB.Text & " " & SliderConReuse.Value.ToString() & " " & SliderConReuse2.Value.ToString()
        r.StartInfo.FileName = Form1.InterpreterPath
        r.StartInfo.UseShellExecute = False
        r.StartInfo.RedirectStandardOutput = True
        r.StartInfo.RedirectStandardOutput = True
        r.StartInfo.CreateNoWindow = True
        r.StartInfo.WindowStyle = ProcessWindowStyle.Hidden
        r.EnableRaisingEvents = True
        r.Start()

        AddHandler r.OutputDataReceived, AddressOf proccess_OutputDataReceived
        r.BeginOutputReadLine()
        r.WaitForExit()

        ProgressTB.Text = "Done! Donor steel designs are generated and ready for review"
        NewSteelSumTB.Text = Value.Split(" ")(0) & " tons of new steel and 0.00 tons of reclaimed steel" & Environment.NewLine & "Total costs " & Value.Split(" ")(8) & Environment.NewLine & "Environmental impact: " & Value.Split(" ")(12) & " euro"
        NewSteelSum2TB.Text = Value.Split(" ")(1) & " tons of new steel and 0.00 tons of reclaimed steel" & Environment.NewLine & "Total costs " & Value.Split(" ")(9) & Environment.NewLine & "Environmental impact: " & Value.Split(" ")(13) & " euro"
        RecSum1TB.Text = Value.Split(" ")(2) & " tons of new steel and " & Value.Split(" ")(4) & " tons of reclaimed steel" & Environment.NewLine & "Total costs " & Value.Split(" ")(10) & Environment.NewLine & "Environmental impact: " & Value.Split(" ")(14) & " euro"
        RecSum2TB.Text = Value.Split(" ")(3) & " tons of new steel and " & Value.Split(" ")(5) & " tons of reclaimed steel" & Environment.NewLine & "Total costs " & Value.Split(" ")(11) & Environment.NewLine & "Environmental impact: " & Value.Split(" ")(15) & " euro"
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim c As New Process
        c.StartInfo.Arguments = "GetCostImpactDetails.py " & DesignNameTB.Text & ".xlsx " & "1"
        c.StartInfo.FileName = Form1.InterpreterPath
        c.StartInfo.UseShellExecute = False
        c.StartInfo.RedirectStandardOutput = True
        c.StartInfo.RedirectStandardOutput = True
        c.StartInfo.CreateNoWindow = True
        c.StartInfo.WindowStyle = ProcessWindowStyle.Hidden
        c.EnableRaisingEvents = True
        c.Start()

        AddHandler c.OutputDataReceived, AddressOf proccess_OutputDataReceived2
        c.BeginOutputReadLine()
        c.WaitForExit()

        Form5.NewSteelPriceTB.Text = Valuee.Split(" ")(0)
        Form5.RecSteelPriceTB.Text = Valuee.Split(" ")(1)
        Form5.MatTestCostsTB.Text = Valuee.Split(" ")(2)
        Form5.StorageCostsTB.Text = Valuee.Split(" ")(3)
        Form5.SBPCostsTB.Text = Valuee.Split(" ")(4)
        Form5.FabCostsTB.Text = Valuee.Split(" ")(5)
        Form5.AssemblyCostsTB.Text = Valuee.Split(" ")(6)
        Form5.EngCostsTB.Text = Valuee.Split(" ")(7)
        Form5.RiskTB.Text = Valuee.Split(" ")(8)
        Form5.SubtotalTB.Text = Valuee.Split(" ")(9)
        Form5.TotalTB.Text = Valuee.Split(" ")(10)
        Form5.ECIA1A3TB.Text = Valuee.Split(" ")(11)
        Form5.ECIA4A5TB.Text = Valuee.Split(" ")(12)
        Form5.ECIBTB.Text = Valuee.Split(" ")(13)
        Form5.ECICTB.Text = Valuee.Split(" ")(14)
        Form5.ECIDTB.Text = Valuee.Split(" ")(15)
        Form5.ECITotalTB.Text = Valuee.Split(" ")(16)
        Form5.PPA1A3.Text = Valuee.Split(" ")(17)
        Form5.PPA4A5.Text = Valuee.Split(" ")(18)
        Form5.PPtotal.Text = Valuee.Split(" ")(19)


        Form5.Show()
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Dim c As New Process
        c.StartInfo.Arguments = "GetCostImpactDetails.py " & DesignNameTB.Text & ".xlsx " & "2"
        c.StartInfo.FileName = Form1.InterpreterPath
        c.StartInfo.UseShellExecute = False
        c.StartInfo.RedirectStandardOutput = True
        c.StartInfo.RedirectStandardOutput = True
        c.StartInfo.CreateNoWindow = True
        c.StartInfo.WindowStyle = ProcessWindowStyle.Hidden
        c.EnableRaisingEvents = True
        c.Start()

        AddHandler c.OutputDataReceived, AddressOf proccess_OutputDataReceived2
        c.BeginOutputReadLine()
        c.WaitForExit()

        Form5.NewSteelPriceTB.Text = Valuee.Split(" ")(0)
        Form5.RecSteelPriceTB.Text = Valuee.Split(" ")(1)
        Form5.MatTestCostsTB.Text = Valuee.Split(" ")(2)
        Form5.StorageCostsTB.Text = Valuee.Split(" ")(3)
        Form5.SBPCostsTB.Text = Valuee.Split(" ")(4)
        Form5.FabCostsTB.Text = Valuee.Split(" ")(5)
        Form5.AssemblyCostsTB.Text = Valuee.Split(" ")(6)
        Form5.EngCostsTB.Text = Valuee.Split(" ")(7)
        Form5.RiskTB.Text = Valuee.Split(" ")(8)
        Form5.SubtotalTB.Text = Valuee.Split(" ")(9)
        Form5.TotalTB.Text = Valuee.Split(" ")(10)
        Form5.ECIA1A3TB.Text = Valuee.Split(" ")(11)
        Form5.ECIA4A5TB.Text = Valuee.Split(" ")(12)
        Form5.ECIBTB.Text = Valuee.Split(" ")(13)
        Form5.ECICTB.Text = Valuee.Split(" ")(14)
        Form5.ECIDTB.Text = Valuee.Split(" ")(15)
        Form5.ECITotalTB.Text = Valuee.Split(" ")(16)
        Form5.PPA1A3.Text = Valuee.Split(" ")(17)
        Form5.PPA4A5.Text = Valuee.Split(" ")(18)
        Form5.PPtotal.Text = Valuee.Split(" ")(19)

        Form5.Show()
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Dim c As New Process
        c.StartInfo.Arguments = "GetCostImpactDetails.py " & DesignNameTB.Text & ".xlsx " & "3"
        c.StartInfo.FileName = Form1.InterpreterPath
        c.StartInfo.UseShellExecute = False
        c.StartInfo.RedirectStandardOutput = True
        c.StartInfo.RedirectStandardOutput = True
        c.StartInfo.CreateNoWindow = True
        c.StartInfo.WindowStyle = ProcessWindowStyle.Hidden
        c.EnableRaisingEvents = True
        c.Start()

        AddHandler c.OutputDataReceived, AddressOf proccess_OutputDataReceived2
        c.BeginOutputReadLine()
        c.WaitForExit()

        Form5.NewSteelPriceTB.Text = Valuee.Split(" ")(0)
        Form5.RecSteelPriceTB.Text = Valuee.Split(" ")(1)
        Form5.MatTestCostsTB.Text = Valuee.Split(" ")(2)
        Form5.StorageCostsTB.Text = Valuee.Split(" ")(3)
        Form5.SBPCostsTB.Text = Valuee.Split(" ")(4)
        Form5.FabCostsTB.Text = Valuee.Split(" ")(5)
        Form5.AssemblyCostsTB.Text = Valuee.Split(" ")(6)
        Form5.EngCostsTB.Text = Valuee.Split(" ")(7)
        Form5.RiskTB.Text = Valuee.Split(" ")(8)
        Form5.SubtotalTB.Text = Valuee.Split(" ")(9)
        Form5.TotalTB.Text = Valuee.Split(" ")(10)
        Form5.ECIA1A3TB.Text = Valuee.Split(" ")(11)
        Form5.ECIA4A5TB.Text = Valuee.Split(" ")(12)
        Form5.ECIBTB.Text = Valuee.Split(" ")(13)
        Form5.ECICTB.Text = Valuee.Split(" ")(14)
        Form5.ECIDTB.Text = Valuee.Split(" ")(15)
        Form5.ECITotalTB.Text = Valuee.Split(" ")(16)
        Form5.PPA1A3.Text = Valuee.Split(" ")(17)
        Form5.PPA4A5.Text = Valuee.Split(" ")(18)
        Form5.PPtotal.Text = Valuee.Split(" ")(19)

        Form5.Show()
    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        FileNametxt3 = My.Computer.FileSystem.CurrentDirectory + "\Solution_cloud.txt"
        System.IO.File.WriteAllText(FileNametxt3, "")
        PercentageReuse.Text = SliderConReuse.Value.ToString() + "%"
        PercentageReuse2.Text = SliderConReuse2.Value.ToString() + "%"
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        My.Computer.FileSystem.WriteAllText(FileNametxt3, DesignNameTB.Text + ", " + Value.Split(" ")(8) + ", " + Value.Split(" ")(12) + ", " + Value.Split(" ")(16) + ", " + Value.Split(" ")(9) + ", " + Value.Split(" ")(13) + ", " + Value.Split(" ")(17) + ", " + Value.Split(" ")(10) + ", " + Value.Split(" ")(14) + ", " + Value.Split(" ")(18) + ", " + Value.Split(" ")(11) + ", " + Value.Split(" ")(15) + ", " + Value.Split(" ")(19) + Environment.NewLine, True)
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim l As New Process
        l.StartInfo.Arguments = "SolCloudPic.py"
        l.StartInfo.FileName = Form1.InterpreterPath
        l.StartInfo.UseShellExecute = False
        l.StartInfo.RedirectStandardOutput = True
        l.StartInfo.RedirectStandardOutput = True
        l.StartInfo.CreateNoWindow = True
        l.StartInfo.WindowStyle = ProcessWindowStyle.Hidden
        l.EnableRaisingEvents = True
        l.Start()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        If ChoiceCloudGraph.Text = "Environmental Cost Indicator (ECI)" Then
            Dim b1 As Image = Image.FromFile(My.Computer.FileSystem.CurrentDirectory + "\SolutionCloudECI.png")
            Dim b2 As New Bitmap(SolutionCloudGraph.Width, SolutionCloudGraph.Height)
            Using g As Graphics = Graphics.FromImage(b2)
                g.DrawImage(b1, 0, 0, SolutionCloudGraph.Width, SolutionCloudGraph.Height)
            End Using

            Dim myImage As Image = b2

            SolutionCloudGraph.Image = myImage
            b1.Dispose()
        End If

        If ChoiceCloudGraph.Text = "Paris Proof Indicator (PPI)" Then
            Dim b1 As Image = Image.FromFile(My.Computer.FileSystem.CurrentDirectory + "\SolutionCloudPPI.png")
            Dim b2 As New Bitmap(SolutionCloudGraph.Width, SolutionCloudGraph.Height)
            Using g As Graphics = Graphics.FromImage(b2)
                g.DrawImage(b1, 0, 0, SolutionCloudGraph.Width, SolutionCloudGraph.Height)
            End Using

            Dim myImage As Image = b2

            SolutionCloudGraph.Image = myImage
            b1.Dispose()

        End If
    End Sub

    Private Sub SliderConReuse_Scroll(sender As Object, e As EventArgs) Handles SliderConReuse.Scroll
        PercentageReuse.Text = SliderConReuse.Value.ToString() + "%"
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        If ModelSelect.Text = "Model 1" Then
            Dim b1 As Image = Image.FromFile(My.Computer.FileSystem.CurrentDirectory + "\DonorUse1.png")
            Dim b2 As New Bitmap(PictureBox1.Width, PictureBox1.Height)
            Using g As Graphics = Graphics.FromImage(b2)
                g.DrawImage(b1, 0, 0, PictureBox1.Width, PictureBox1.Height)
            End Using

            Dim myImage As Image = b2

            PictureBox1.Image = myImage
            b1.Dispose()

        End If
        If ModelSelect.Text = "Model 2" Then
            Dim b1 As Image = Image.FromFile(My.Computer.FileSystem.CurrentDirectory + "\DonorUse2.png")
            Dim b2 As New Bitmap(PictureBox1.Width, PictureBox1.Height)
            Using g As Graphics = Graphics.FromImage(b2)
                g.DrawImage(b1, 0, 0, PictureBox1.Width, PictureBox1.Height)
            End Using

            Dim myImage As Image = b2

            PictureBox1.Image = myImage
            b1.Dispose()
        End If
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        Dim c As New Process
        c.StartInfo.Arguments = "GetCostImpactDetails.py " & DesignNameTB.Text & ".xlsx " & "0"
        c.StartInfo.FileName = Form1.InterpreterPath
        c.StartInfo.UseShellExecute = False
        c.StartInfo.RedirectStandardOutput = True
        c.StartInfo.RedirectStandardOutput = True
        c.StartInfo.CreateNoWindow = True
        c.StartInfo.WindowStyle = ProcessWindowStyle.Hidden
        c.EnableRaisingEvents = True
        c.Start()

        AddHandler c.OutputDataReceived, AddressOf proccess_OutputDataReceived2
        c.BeginOutputReadLine()
        c.WaitForExit()

        Form5.NewSteelPriceTB.Text = Valuee.Split(" ")(0)
        Form5.RecSteelPriceTB.Text = Valuee.Split(" ")(1)
        Form5.MatTestCostsTB.Text = Valuee.Split(" ")(2)
        Form5.StorageCostsTB.Text = Valuee.Split(" ")(3)
        Form5.SBPCostsTB.Text = Valuee.Split(" ")(4)
        Form5.FabCostsTB.Text = Valuee.Split(" ")(5)
        Form5.AssemblyCostsTB.Text = Valuee.Split(" ")(6)
        Form5.EngCostsTB.Text = Valuee.Split(" ")(7)
        Form5.RiskTB.Text = Valuee.Split(" ")(8)
        Form5.SubtotalTB.Text = Valuee.Split(" ")(9)
        Form5.TotalTB.Text = Valuee.Split(" ")(10)
        Form5.ECIA1A3TB.Text = Valuee.Split(" ")(11)
        Form5.ECIA4A5TB.Text = Valuee.Split(" ")(12)
        Form5.ECIBTB.Text = Valuee.Split(" ")(13)
        Form5.ECICTB.Text = Valuee.Split(" ")(14)
        Form5.ECIDTB.Text = Valuee.Split(" ")(15)
        Form5.ECITotalTB.Text = Valuee.Split(" ")(16)
        Form5.PPA1A3.Text = Valuee.Split(" ")(17)
        Form5.PPA4A5.Text = Valuee.Split(" ")(18)
        Form5.PPtotal.Text = Valuee.Split(" ")(19)

        Form5.Show()
    End Sub

    Private Sub SliderConReuse2_Scroll(sender As Object, e As EventArgs) Handles SliderConReuse2.Scroll
        PercentageReuse2.Text = SliderConReuse2.Value.ToString() + "%"
    End Sub

End Class